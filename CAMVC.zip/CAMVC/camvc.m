function [U, A, Z, obj] = CAMVC(X, n, k, m, param)
% 
num_view = length(X);
for i = 1:num_view
    A{i} = zeros(size(X{i},1), m*k);
end
alpha = param.alpha;
beta  = param.beta;

if size(X{1},2)~=n
    for iv = 1:num_view
        X{iv} = X{iv}';
    end
end
for iv = 1:num_view
    X{iv} = NormalizeFea(X{iv},0);
end
clear iv

% initialization
I = eye(k); Y= [];
for ik = 1:k
    Y = [Y repmat(I(:,ik),1,m)];
end
clear I


for iv = 1:num_view
    [Up,~,Sp] = svd(A{iv}*Y', 'econ');
    P{iv} = Up*Sp';
end
clear Up Sp


w = ones(1, num_view);%/num_view;


MAX_ITER = 15;

for iter = 1:MAX_ITER
  

    tZ1 = 0; tZ2=  0;
    for iv = 1:num_view
        tZ1 = tZ1 + w(iv)^2*A{iv}'*A{iv};
        tZ2 = tZ2 + w(iv)^2*A{iv}'*X{iv};
    end
     Z = (tZ1 + beta*eye(m*k))\tZ2;

        % A step
    for iv = 1:num_view
        A{iv} = (X{iv}*Z' + alpha*P{iv}*Y)/(Z*Z' + alpha*eye(m*k));
    end
 
    % P step
     for iv = 1:num_view
        [Up,~,Sp] = svd(A{iv}*Y', 'econ');
        P{iv} = Up*Sp';
     end
     clear Up Sp

    obj(iter) = calobj(X, A, Z, P, Y, w, num_view, alpha, beta);
    if (iter>2) && ( abs((obj(iter-1)-obj(iter))/(obj(iter-1)))<1e-4|| iter>MAX_ITER)
        break
    end

end

U = Z';

end

function obj = calobj(X, A, Z, P, Y, w, num_view, alpha, beta)
obj = 0;
for iv = 1:num_view
    err = X{iv}-A{iv}*Z;
    err2 = A{iv} - P{iv}*Y;
    obj = obj + w(iv)^2*(sum(sum(err.*err)) + alpha*sum(sum(err2.*err2)));
end
err3 = Z;
obj = obj + beta*sum(sum(err3.*err3));

end
