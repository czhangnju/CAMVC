%clear;
%clc;
warning off;
addpath(genpath('./'));

%% dataset
ds = {'BBCSport.mat'};
metric = {'ACC','nmi','Purity','Fscore','Precision','Recall','AR','Entropy'};

for dsi = 1:length(ds)
    %% load data & make folder
    dataName = ds{dsi};
    load(dataName);
    k = length(unique(Y));
    n = length(Y);
%     matpath = strcat(resPath,dataName);
%     txtpath = strcat(resPath,strcat(dataName,'.txt'));
%     if (~exist(matpath,'file'))
%         mkdir(matpath);
%         addpath(genpath(matpath));
%     end
    %% initialize A
    for iv = 1:length(X)
        if size(X{iv},2)~= n
            X{iv} = X{iv}';
        end
        X{iv} = NormalizeFea(X{iv}, 0);
    end
    %% param setting
    MM = [1 3 5];
    AP = [1e-3, 1e-2, 1e-1, 1e0, 1e1];
    BT = [1e-2, 1e-1, 1e0, 1e1, 1e2, 1e3];
    %% 
    perf = []; perf_svd=[];
    for rp0 = 1:length(MM)
        m = MM(rp0);
        for rp1 = 1:length(AP)
            for rp2 = 1:length(BT)   
                 param.alpha = AP(rp1);
                 param.beta = BT(rp2);
            tic
            [U, A, Z, obj] = camvc(X, n, k, m, param);
            [res] = myNMIACCwithmean(U,Y,k); %[ACC nmi Purity Fscore Precision Recall AR Entropy];
            time  = toc;   
            fprintf("\n ITER: (%d, %d, %d) ACC, NMI, Purity, F: %.4f, %.4f, %.4f, %.4f, %.4f, %.4f \n", rp0, rp1, rp2, res(1), res(2),res(3),res(4));
            end
        end
    end
end
